import logo from "./logo.svg";
import "./App.css";
import Cart from "./components/cart";

function App() {
  return (
    <div className="App">
      <main>
        <Cart /> {/* Render the Cart component */}
      </main>
    </div>
  );
}

export default App;
